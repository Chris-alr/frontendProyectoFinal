<template>
<div align="center" class="textos">

    <h1 class="textosh1" >Gracias por su compra!</h1>
    <h2 class="textosh2">estamos trabajando en su orden</h2>
    <img src="../assets/gracias.png" class="mt-10">

</div>
    
</template>
<script>
export default {
    
}
</script>
<style >
    .textos{
        margin-top:8%;
    }
    .textosh1{
      font-size: 4rem;
    }
    .textosh2{
        font-size: 2rem;
    }
</style>