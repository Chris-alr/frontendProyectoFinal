<template>

<div align="center">

<h1 align="center" class="uno">Acerca De Nosotros</h1>
  <img class="imagen" src="../assets/sushixa.png">
  <div>
  <h2>Somos un local de sushi que empezo su carrera el 2019 y desde entonces nos centramos en servir los mejores productos a nuestros clientes!</h2>
</div>

</div>

  
</template>
<style scoped>
  .uno{
      font-family: 'Fira sans',cursive;
      margin-top:1%;
      font-size: 4rem;
      color:rgba(18, 55, 122, 0.979);
  }

</style>
